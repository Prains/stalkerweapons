ITEM.name = "MP-5"
ITEM.desc = "MP-5 \nТут %ClipOne|0% патронов в магазине."
ITEM.model = "models/weapons/w_mp5.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_mp5"
ITEM.height = 3
ITEM.width = 2
ITEM.price = 4500
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}