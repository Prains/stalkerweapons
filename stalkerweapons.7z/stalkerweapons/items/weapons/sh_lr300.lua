ITEM.name = "LR 300"
ITEM.desc = "LR 300 \nТут %ClipOne|0% патронов в магазине."
ITEM.model = "models/weapons/w_stalker_lr300.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_lr300"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 4500
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}