ITEM.name = "Chaser 13"
ITEM.desc = "Chaser 13 \nТут %ClipOne|0% патронов в магазине."
ITEM.model = "models/weapons/w_stalker_winchester.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_chaser13"
ITEM.height = 3
ITEM.width = 2
ITEM.price = 2000
ITEM.iconCam = {
	ang	= Angle(-1.4573881626129, 270.6755065918, 0),
	fov	= 12.796572802781,
	pos	= Vector(-1.2, 200, 0)
}