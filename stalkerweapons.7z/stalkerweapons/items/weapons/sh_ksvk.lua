ITEM.name = "KSVK"
ITEM.desc = "KSVK \nТут %ClipOne|0% патронов в магазине."
ITEM.model = "models/weapons/w_stalker_vss.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_ksvk"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 4500
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}